// import api from "./axiosInstance";

// // get all categories
// export const getCategoriesApi = () =>
//   api.get("/category/list");

// // get subcategories by category
// export const getSubCategoriesApi = (categoryId) =>
//   api.get(`/subcategory?category_id=${categoryId}`);
