// import React from "react";
// import { BrowserRouter } from "react-router-dom";
// import AppRouter from "./routes/index.jsx";
// import { ExpertProvider } from "./shared/context/ExpertContext.jsx";
// import { WalletProvider } from "./shared/context/WalletContext.jsx";



// export default function App() {
//   return (
//     <BrowserRouter>
     

//  <ExpertProvider>
//   <WalletProvider>
//       <AppRouter />
// </WalletProvider>
//       </ExpertProvider> 
//     </BrowserRouter>
//   );
// }
