import React, { useState, useMemo, useEffect, useRef } from "react";
import {
  Popover,
  HeaderRow,
  Title,
  MarkAll,
  Tabs,
  Tab,
  Section,
  PopItem,
  Meta,
  ActionRow,
  ActionBtn,
  Footer,
  ViewAll,
  Empty,
  RingDot,
} from "../styles/Notification.styles";
import { useNavigate } from "react-router-dom";

export default function NotificationPopover({
  notifications = [],
  unreadCount = 0,
  markAllRead,
  onAccept,
  onDecline,
}) {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("calls");
  const ringAudioRef = useRef(null);

  /* ---------------- SPLIT DATA ---------------- */
  const { calls, chats } = useMemo(() => ({
    calls: notifications.filter((n) => n.type === "voice_call"),
    chats: notifications.filter((n) => n.type !== "voice_call"),
  }), [notifications]);

  /* ---------------- RING SOUND ---------------- */
  useEffect(() => {
    const hasRinging = calls.some((c) => c.status === "ringing");
    if (hasRinging && ringAudioRef.current) {
      ringAudioRef.current.play().catch(() => {});
    }
  }, [calls]);

  return (
    <Popover>
      <audio
        ref={ringAudioRef}
        src="/sounds/incoming-call.mp3"
        preload="auto"
      />

      {/* HEADER */}
      <HeaderRow>
        <Title>Notifications</Title>
        {unreadCount > 0 && <MarkAll onClick={markAllRead}>Mark all</MarkAll>}
      </HeaderRow>

      {/* TABS */}
      <Tabs>
        <Tab active={activeTab === "calls"} onClick={() => setActiveTab("calls")}>
          📞 Calls {calls.length > 0 && <RingDot />}
        </Tab>
        <Tab active={activeTab === "chats"} onClick={() => setActiveTab("chats")}>
          💬 Chats
        </Tab>
      </Tabs>

      {/* CALL TAB */}
      {activeTab === "calls" && (
        <Section>
          {calls.length === 0 ? (
            <Empty>No call notifications</Empty>
          ) : (
            calls.map((n) => (
              <PopItem key={n.id} ringing={n.status === "ringing"}>
                <strong>{n.title}</strong>
                {n.meta && <Meta>{n.meta}</Meta>}

                {(n.status === "pending" || n.status === "ringing") && (
                  <ActionRow>
                    <ActionBtn success onClick={() => onAccept(n)}>
                      Accept
                    </ActionBtn>
                    <ActionBtn danger outline onClick={() => onDecline(n)}>
                      Decline
                    </ActionBtn>
                  </ActionRow>
                )}
              </PopItem>
            ))
          )}
        </Section>
      )}

      {/* CHAT TAB */}
      {activeTab === "chats" && (
        <Section>
          {chats.length === 0 ? (
            <Empty>No chat notifications</Empty>
          ) : (
            chats.map((n) => (
              <PopItem
                key={n.id}
                clickable
                onClick={() => navigate(`/expert/chat/${n.payload.roomId}`)}
              >
                <strong>{n.title}</strong>
                {n.meta && <Meta>{n.meta}</Meta>}
              </PopItem>
            ))
          )}
        </Section>
      )}

      <Footer>
        <ViewAll>View all</ViewAll>
      </Footer>
    </Popover>
  );
}
