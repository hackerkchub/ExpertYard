import React, { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useExpertNotifications } from "../context/ExpertNotificationsContext";

import {
  QueueCardWrap,
  QueueTabs,
  QueueItem,
  ActionBtn,
  RedDot,
  StatusBadge,
} from "../styles/Dashboard.styles";

export default function QueueCard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("chat");

  const {
    notifications,
    acceptRequest,
    declineRequest,
  } = useExpertNotifications();

  /* ----------------------------------
     SPLIT CHAT & CALL
  ---------------------------------- */
  const chatRequests = useMemo(
    () => notifications.filter((n) => n.type === "chat_request"),
    [notifications]
  );

  const callRequests = useMemo(
    () => notifications.filter((n) => n.type === "call_request"),
    [notifications]
  );

  const activeList =
    activeTab === "chat" ? chatRequests : callRequests;

  /* ----------------------------------
     HANDLERS (✅ FIXED)
  ---------------------------------- */
  const handleAccept = (req) => {
    // ✅ ALWAYS pass full object
    acceptRequest(req);

    // ❌ navigation yaha mat karo
    // ✅ call/chat redirect socket events se hoga
  };

  const handleDecline = (req) => {
    declineRequest(req);
  };

  return (
    <QueueCardWrap>
      {/* ---------------- TABS ---------------- */}
      <QueueTabs>
        <button
          className={activeTab === "chat" ? "active" : ""}
          onClick={() => setActiveTab("chat")}
        >
          💬 Chat ({chatRequests.length})
        </button>

        <button
          className={activeTab === "call" ? "active" : ""}
          onClick={() => setActiveTab("call")}
        >
          📞 Calls ({callRequests.length})
          {callRequests.length > 0 && <RedDot />}
        </button>
      </QueueTabs>

      {/* ---------------- LIST ---------------- */}
      {activeList.length === 0 ? (
        <div style={{ padding: 24, textAlign: "center", color: "#64748b" }}>
          No pending {activeTab} requests
        </div>
      ) : (
        activeList.map((req) => (
          <QueueItem key={req.id} className={req.status || "pending"}>
            <div>
              <strong>{req.title}</strong>

              <StatusBadge status={req.status || "pending"}>
                {req.status === "pending" && "⏳ Pending"}
                {req.status === "accepted" && "✅ Accepted"}
                {req.status === "rejected" && "❌ Rejected"}
                {req.status === "cancelled" && "🚫 Cancelled"}
              </StatusBadge>

              <span>{req.meta}</span>
            </div>

            <div>
              {req.status === "pending" ? (
                <>
                  <ActionBtn
                    className="accept"
                    onClick={() => handleAccept(req)}
                  >
                    Accept
                  </ActionBtn>

                  <ActionBtn
                    className="decline"
                    onClick={() => handleDecline(req)}
                  >
                    Decline
                  </ActionBtn>
                </>
              ) : (
                <ActionBtn disabled>Closed</ActionBtn>
              )}
            </div>
          </QueueItem>
        ))
      )}
    </QueueCardWrap>
  );
}
