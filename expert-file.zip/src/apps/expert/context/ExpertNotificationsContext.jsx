import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  useCallback,
} from "react";
import { socket } from "../../../shared/api/socket";

const Ctx = createContext(null);
const STORAGE_KEY = "expert_notifications_v2";

/* ----------------------------------
   Helper
---------------------------------- */
const getSafeUserName = (user_name, user_id) => {
  if (typeof user_name === "string" && user_name.trim()) {
    return user_name.trim();
  }
  return `User #${user_id}`;
};

export function ExpertNotificationsProvider({ children }) {
  /* ----------------------------------
     STATE
  ---------------------------------- */
  const [notifications, setNotifications] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  /* ----------------------------------
     PERSIST
  ---------------------------------- */
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications));
  }, [notifications]);

  /* ----------------------------------
     UNREAD COUNT
  ---------------------------------- */
  const unreadCount = useMemo(
    () =>
      notifications.filter(
        (n) => n.unread && !["cancelled", "ended", "rejected"].includes(n.status)
      ).length,
    [notifications]
  );

  /* =====================================================
     🔔 CHAT REQUEST
  ===================================================== */
  useEffect(() => {
    const onIncomingChat = ({ request_id, user_id, user_name, expert_id }) => {
      const safeName = getSafeUserName(user_name, user_id);

      setNotifications((prev) => {
        if (prev.some((n) => n.id === request_id)) return prev;

        return [
          {
            id: request_id,
            type: "chat_request",
            status: "pending",
            title: `Chat request from ${safeName}`,
            meta: "Accept or decline",
            unread: true,
            payload: {
              request_id,
              user_id,
              expert_id,
              user_name: safeName,
            },
            createdAt: Date.now(),
          },
          ...prev,
        ];
      });
    };

    socket.on("incoming_chat_request", onIncomingChat);
    return () => socket.off("incoming_chat_request", onIncomingChat);
  }, []);

  /* =====================================================
     📞 VOICE CALL
  ===================================================== */
  useEffect(() => {
    const onIncomingCall = ({ callId, fromUserId }) => {
      setNotifications((prev) => {
        if (prev.some((n) => n.id === `call_${callId}`)) return prev;

        return [
          {
            id: `call_${callId}`,
            type: "call_request",
            status: "ringing",
            title: `Incoming call`,
            meta: `User #${fromUserId}`,
            unread: true,
            payload: { callId, user_id: fromUserId },
            createdAt: Date.now(),
          },
          ...prev,
        ];
      });
    };

    socket.on("call:incoming", onIncomingCall);
    return () => socket.off("call:incoming", onIncomingCall);
  }, []);

  /* =====================================================
     🔚 CALL ENDED / MISSED
  ===================================================== */
  useEffect(() => {
    const onCallEnded = ({ callId, reason }) => {
      setNotifications((prev) =>
        prev.map((n) =>
          n.id === `call_${callId}`
            ? { ...n, status: reason || "ended", unread: false }
            : n
        )
      );
    };

    socket.on("call:ended", onCallEnded);
    return () => socket.off("call:ended", onCallEnded);
  }, []);

  /* =====================================================
     HELPERS
  ===================================================== */
  const removeById = useCallback((id) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications((prev) =>
      prev.map((n) => ({ ...n, unread: false }))
    );
  }, []);

  /* =====================================================
     ✅ GENERIC ACCEPT / DECLINE (🔥 IMPORTANT)
  ===================================================== */
  const acceptRequest = useCallback(
    (notification) => {
      if (!notification) return;

      // 💬 CHAT
      if (notification.type === "chat_request") {
        socket.emit("accept_chat", {
          request_id: notification.payload.request_id,
        });
        removeById(notification.id);
        return;
      }

      // 📞 CALL
      if (notification.type === "call_request") {
        socket.emit("call:accept", {
          callId: notification.payload.callId,
        });
        removeById(notification.id);
        return;
      }
    },
    [removeById]
  );

  const declineRequest = useCallback(
    (notification) => {
      if (!notification) return;

      // 💬 CHAT
      if (notification.type === "chat_request") {
        socket.emit("reject_chat", {
          request_id: notification.payload.request_id,
        });
        removeById(notification.id);
        return;
      }

      // 📞 CALL
      if (notification.type === "call_request") {
        socket.emit("call:reject", {
          callId: notification.payload.callId,
        });
        removeById(notification.id);
        return;
      }
    },
    [removeById]
  );

  /* =====================================================
     CONTEXT VALUE
  ===================================================== */
  const value = useMemo(
    () => ({
      notifications,
      unreadCount,
      markAllRead,
      acceptRequest,
      declineRequest,
    }),
    [notifications, unreadCount, acceptRequest, declineRequest]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useExpertNotifications() {
  const ctx = useContext(Ctx);
  if (!ctx) {
    throw new Error(
      "useExpertNotifications must be used within ExpertNotificationsProvider"
    );
  }
  return ctx;
}
