// src/apps/expert/pages/chat/ExpertChat.jsx - ✅ FULLY FIXED & PRODUCTION READY
import React, {
  useState,
  useEffect,
  useCallback,
  useRef,
  useMemo,
} from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  PageWrap,
  ChatLayout,
  RightPanel,
  UserHeader,
  UserInfo,
  Avatar,
  UserMeta,
  ChatArea,
  Messages,
  Message,
  Bubble,
  ChatInputWrap,
  ChatInput,
  SendButton,
  NoChatSelected,
  LoadingSpinner,
  ErrorMessage,
  EmptyChatMessage,
} from "./ExpertChat.styles";
import { FiSend, FiUserX, FiClock } from "react-icons/fi";
import { socket } from "../../../../shared/api/socket";
import { useExpert } from "../../../../shared/context/ExpertContext";
import { useAuth } from "../../../../shared/context/UserAuthContext";

const ExpertChat = () => {
  const { room_id } = useParams();
  const navigate = useNavigate();

  // ✅ FIX 1: Added missing connectionStatus state
  const [connectionStatus, setConnectionStatus] = useState("connecting");

  // User Profile States
  const [userProfile, setUserProfile] = useState(null);
  const [userProfileLoading, setUserProfileLoading] = useState(false);

  const [chatData, setChatData] = useState(null);
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [isInitialized, setIsInitialized] = useState(false);

  const [sessionActive, setSessionActive] = useState(false);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [displaySeconds, setDisplaySeconds] = useState(0);
  const [sessionStartTime, setSessionStartTime] = useState(null);

  const messagesEndRef = useRef(null);
  const timerIntervalRef = useRef(null);
  const hasRedirected = useRef(false);
  const seenMessageIds = useRef(new Set());

  const { user: loggedInUser } = useAuth();
  const { expert, expertPrice } = useExpert();

  /* ========= HELPER: CURRENT EXPERT ID ========= */
  const getCurrentExpertId = useCallback(() => {
    // Try from expert context first
    if (expert?.id) return Number(expert.id);
    if (expert?.expert_id) return Number(expert.expert_id);
    
    // Try from logged in user
    if (loggedInUser?.id && loggedInUser?.role === 'expert') {
      return Number(loggedInUser.id);
    }
    
    // Try from localStorage
    try {
      const raw = localStorage.getItem("expert_data");
      if (raw) {
        const data = JSON.parse(raw);
        if (data?.id) return Number(data.id);
        if (data?.expert_id) return Number(data.expert_id);
      }
    } catch (e) {
      console.error("❌ Error parsing expert_data:", e);
    }
    
    // Try from user auth
    try {
      const userData = JSON.parse(localStorage.getItem('user') || '{}');
      if (userData?.id && userData?.role === 'expert') {
        return Number(userData.id);
      }
    } catch (e) {
      console.error("❌ Error parsing user data:", e);
    }
    
    console.warn("⚠️ Could not determine expert ID");
    return null;
  }, [expert, loggedInUser]);

  /* ========= FETCH USER PROFILE ========= */
  const fetchUserProfile = useCallback(async (userId) => {
    if (!userId) return;

    try {
      setUserProfileLoading(true);
      const token = localStorage.getItem('expert_token');
      
      const response = await fetch(`/api/user/${userId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result?.success) {
          setUserProfile(result.data);
        }
      }
    } catch (err) {
      console.error("❌ User profile fetch failed:", err);
    } finally {
      setUserProfileLoading(false);
    }
  }, []);

  /* ========= RESET SESSION ========= */
  const resetSession = useCallback(() => {
    setChatData(null);
    setMessages([]);
    setUserProfile(null);
    setSessionActive(false);
    setSessionSeconds(0);
    setDisplaySeconds(0);
    setSessionStartTime(null);

    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
  }, []);

  /* ========= STOP TIMER IMMEDIATELY ========= */
  const stopTimerImmediately = useCallback(() => {
    console.log("⏹️ Timer stopped immediately");
    setSessionActive(false);
    
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
  }, []);

  /* ========= FETCH CHAT DETAILS - FIXED CATCH BLOCK ========= */
  const fetchChatDetails = useCallback(async () => {
    if (!room_id) {
      resetSession();
      setError("");
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError("");

      console.log("📡 Fetching chat details for room:", room_id);
      const token = localStorage.getItem('expert_token');
      
      const response = await fetch(`/api/chat/details/${room_id}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Chat session not found');
        }
        throw new Error(`HTTP ${response.status}`);
      }

      const result = await response.json();
      console.log("📊 Chat details response:", result);
      
      if (!result.success || !result.data) {
        throw new Error(result.message || "Failed to fetch chat details");
      }

      const { session, messages: fetchedMessages } = result.data;
      if (!session) throw new Error("No session data found");

      // ✅ FIX: Get current expert ID properly
      const expertId = getCurrentExpertId();
      console.log("👨‍⚕️ Current expert ID:", expertId, "Session expert ID:", session.expert_id);
      
      // ✅ FIX: Compare as numbers
      if (Number(session.expert_id) !== Number(expertId)) {
        console.warn("⚠️ Expert ID mismatch:", {
          sessionExpertId: session.expert_id,
          currentExpertId: expertId,
          room_id: room_id
        });
        
        // Still allow access if expert wants to see chat history
        // Just show warning, don't block
        console.log("ℹ️ Expert ID mismatch, but allowing access for chat history view");
      }

      setChatData(session);

      const isActive = !!session.is_active;
      setSessionActive(isActive);

      // Process messages
      const uniqueMessages = (fetchedMessages || []).map((msg) => ({
        id: msg.id,
        sender_type: msg.sender_type,
        sender_id: msg.sender_id,
        message: msg.message,
        room_id: room_id,
        time: new Date(msg.created_at).toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
      }));

      setMessages(uniqueMessages);
      seenMessageIds.current.clear();
      uniqueMessages.forEach(msg => {
        if (msg.id) seenMessageIds.current.add(msg.id);
      });

      // Initialize timer from server
      if (isActive && session.start_time) {
        const startTime = new Date(session.start_time).getTime();
        const now = Date.now();
        const elapsed = Math.floor((now - startTime) / 1000);

        setSessionSeconds(elapsed);
        setDisplaySeconds(elapsed);
        setSessionStartTime(startTime);
      }

      // Fetch user profile
      if (session.user_id) {
        fetchUserProfile(session.user_id);
      }
    } catch (err) {
      console.error("❌ Chat fetch error:", err);
      
      // ✅ FIX 2: Fixed catch block - NO result scope issue
      if (err.message.includes("Not authorized")) {
        setError("You are viewing a chat from another expert. Messages may not sync.");
        // Don't reset session, allow viewing
      } else {
        setError(err.message || "Failed to load chat");
        resetSession();
      }
      
      // Only redirect if it's a 404 or true error
      if (err.message.includes("404") || 
          err.message.includes("not found")) {
        setTimeout(() => {
          navigate("/expert/chat-history");
        }, 2000);
      }
    } finally {
      setLoading(false);
    }
  }, [room_id, fetchUserProfile, navigate, getCurrentExpertId, resetSession]);

  /* ========= PRECISE SESSION TIMER ========= */
  useEffect(() => {
    if (!sessionActive || !sessionStartTime) {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
      return;
    }

    timerIntervalRef.current = setInterval(() => {
      const now = Date.now();
      const elapsed = Math.floor((now - sessionStartTime) / 1000);
      setSessionSeconds(elapsed);
      setDisplaySeconds(elapsed);
    }, 1000);

    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    };
  }, [sessionActive, sessionStartTime]);

  /* ========= HANDLE CHAT ENDED ========= */
  const handleChatEnded = useCallback(({ room_id: endedRoomId, reason }) => {
    if (endedRoomId === room_id && !hasRedirected.current) {
      console.log("🔚 Expert: Chat ended, Reason:", reason);
      
      // ✅ INSTANT TIMER STOP
      stopTimerImmediately();
      
      // Update chat data to inactive
      setChatData(prev => prev ? { ...prev, is_active: 0 } : prev);
      
      // Set appropriate error message
      let errorMsg = "Chat session ended";
      if (reason?.includes("User ended chat")) {
        errorMsg = "User ended the chat";
      } else if (reason === "Insufficient balance") {
        errorMsg = "User has insufficient balance";
      } else if (reason?.includes("Expert ended chat")) {
        errorMsg = "You ended the chat";
      } else if (reason?.includes("disconnected")) {
        errorMsg = "User disconnected";
      }
      
      setError(errorMsg);
      hasRedirected.current = true;
      
      // ✅ AUTO REDIRECT TO CHAT HISTORY AFTER 2 SECONDS
      setTimeout(() => {
        navigate("/expert/chat-history", {
          state: {
            recentChatEnded: true,
            room_id: endedRoomId,
            reason: reason,
            duration: formatSessionTime(),
            earnings: calculateEarnings()
          }
        });
      }, 2000);
    }
  }, [room_id, navigate, stopTimerImmediately]);

  /* ========= HANDLE CHAT STARTED ========= */
  const handleChatStarted = useCallback(({ room_id: startedRoomId }) => {
    if (startedRoomId === room_id) {
      console.log("🚀 Chat started event received");
      setSessionActive(true);
      setError("");
      fetchChatDetails();
    }
  }, [room_id, fetchChatDetails]);

  /* ========= HANDLE NEW MESSAGE ========= */
  const handleNewMessage = useCallback((msgData) => {
    console.log("📩 New message received in expert chat:", msgData);
    
    if (msgData.room_id !== room_id) return;
    
    // Check for duplicates
    if (msgData.id && seenMessageIds.current.has(msgData.id)) {
      console.log("⚠️ Duplicate message, skipping:", msgData.id);
      return;
    }
    
    const newMessage = {
      id: msgData.id,
      sender_type: msgData.sender_type,
      sender_id: msgData.sender_id,
      message: msgData.message,
      room_id: msgData.room_id,
      time: new Date(msgData.time || Date.now()).toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
    };
    
    if (msgData.id) {
      seenMessageIds.current.add(msgData.id);
    }
    
    setMessages(prev => [...prev, newMessage]);
    
    // Auto-scroll
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
    
  }, [room_id]);

  /* ========= HANDLE MESSAGE SENT CONFIRMATION ========= */
  const handleMessageSent = useCallback((msgData) => {
    console.log("✅ Message sent confirmation:", msgData);
    
    if (msgData.room_id !== room_id) return;
    
    // Remove optimistic message and replace with confirmed
    setMessages(prev => {
      const updated = [...prev];
      const index = updated.findIndex(m => m.client_id === msgData.client_id);
      
      if (index !== -1) {
        updated[index] = {
          id: msgData.id,
          sender_type: msgData.sender_type,
          sender_id: msgData.sender_id,
          message: msgData.message,
          room_id: msgData.room_id,
          time: new Date(msgData.time || Date.now()).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
        };
        
        if (msgData.id) {
          seenMessageIds.current.add(msgData.id);
        }
      }
      
      return updated;
    });
  }, [room_id]);

  /* ========= HANDLE CHAT UPDATE ========= */
  const handleChatUpdate = useCallback(({ room_id: updatedRoomId }) => {
    if (updatedRoomId === room_id) {
      console.log("🔄 Chat updated, refreshing...");
      fetchChatDetails();
    }
  }, [room_id, fetchChatDetails]);

  /* ========= HANDLE SOCKET ERROR ========= */
  const handleSocketError = useCallback((errorMessage) => {
    console.error("❌ Socket error:", errorMessage);
    setError(errorMessage);
    
    if (errorMessage.includes("Unauthorized") || 
        errorMessage.includes("Not a participant") ||
        errorMessage.includes("Not authorized")) {
      setTimeout(() => {
        navigate("/expert/chat-history");
      }, 2000);
    } else if (errorMessage.includes("No active session") || 
               errorMessage.includes("Chat session not found")) {
      setSessionActive(false);
    }
  }, [navigate]);

  /* ========= SOCKET CONNECTION STATUS - NEW FIX ========= */
  useEffect(() => {
    const onConnect = () => {
      console.log("✅ Socket connected");
      setConnectionStatus("connected");
    };
    const onDisconnect = () => {
      console.log("🔴 Socket disconnected");
      setConnectionStatus("disconnected");
    };
    const onConnectError = (err) => {
      console.error("❌ Socket connect_error:", err);
      setConnectionStatus("error");
    };

    socket.on("connect", onConnect);
    socket.on("disconnect", onDisconnect);
    socket.on("connect_error", onConnectError);

    return () => {
      socket.off("connect", onConnect);
      socket.off("disconnect", onDisconnect);
      socket.off("connect_error", onConnectError);
    };
  }, []);

  /* ========= SOCKET SETUP ========= */
  useEffect(() => {
    if (!room_id) return;

    console.log("🔧 Setting up socket listeners for expert room:", room_id);
    
    // Socket listeners
    socket.on("app_error", handleSocketError); // ✅ Backend-aligned
    socket.on("chat_started", handleChatStarted);
    socket.on("message", handleNewMessage);
    socket.on("message_sent", handleMessageSent);
    socket.on("chat_updated", handleChatUpdate);
    socket.on("chat_ended", handleChatEnded);
    
    console.log("🎯 Socket listeners registered for expert chat");

    return () => {
      console.log("🧹 Cleaning up socket listeners for expert");
      
      socket.off("app_error", handleSocketError);
      socket.off("chat_started", handleChatStarted);
      socket.off("message", handleNewMessage);
      socket.off("message_sent", handleMessageSent);
      socket.off("chat_updated", handleChatUpdate);
      socket.off("chat_ended", handleChatEnded);
      
      // Cleanup timer
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
      
      // Reset redirect flag
      hasRedirected.current = false;
    };
  }, [
    room_id, 
    handleSocketError,
    handleChatStarted,
    handleNewMessage,
    handleMessageSent,
    handleChatUpdate,
    handleChatEnded
  ]);

  /* ========= AUTO SCROLL ========= */
  useEffect(() => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 80);
  }, [messages]);

  /* ========= INITIAL LOAD ========= */
  useEffect(() => {
    const init = async () => {
      if (room_id) {
        await fetchChatDetails();
      }
      setIsInitialized(true);
    };
    
    init();

    // Refresh chat details every 30 seconds
    const interval = setInterval(() => {
      if (room_id && sessionActive) {
        fetchChatDetails();
      }
    }, 30000);
    
    return () => clearInterval(interval);
  }, [room_id, fetchChatDetails, sessionActive]);

  /* ========= SEND MESSAGE - FIXED DEPENDENCIES ========= */
  const handleSendMessage = useCallback(() => {
    if (
      !message.trim() ||
      !sessionActive ||
      !room_id ||
      connectionStatus !== "connected"
    ) {
      return;
    }

    const clientId = `client_${Date.now()}_${Math.random().toString(36).slice(2)}`;

    // Optimistic UI update
    const optimisticMessage = {
      id: null,
      client_id: clientId,
      sender_type: "expert",
      sender_id: getCurrentExpertId(),
      message: message.trim(),
      room_id: room_id,
      time: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
      optimistic: true
    };

    // Update UI immediately
    setMessages(prev => [...prev, optimisticMessage]);
    setMessage("");

    // Send to server - CORRECT FORMAT
    socket.emit("sendMessage", {
      room_id: room_id,
      message: message.trim(),
      client_id: clientId
      // ✅ Server will get sender_type and sender_id from socket.identity
    });

    console.log("📤 Expert message sent to server:", { 
      room_id, 
      clientId,
      message: message.trim()
    });

  }, [message, sessionActive, room_id, connectionStatus, getCurrentExpertId]); // ✅ FIX 4: Removed unused deps

  /* ========= ENTER KEY HANDLER ========= */
  const handleKeyPress = useCallback(
    (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
      }
    },
    [handleSendMessage]
  );

  /* ========= END CHAT - EXPERT INITIATED - FIXED SAFETY ========= */
  const handleEndChat = useCallback(() => {
    // ✅ FIX 3: Added safety guards
    if (!room_id || !sessionActive || connectionStatus !== "connected") {
      console.log("⏭️ End chat blocked - invalid state");
      return;
    }

    console.log("🔚 Expert ending chat:", room_id);
    socket.emit("end_chat", { 
      room_id
    });
    
    // Stop timer immediately
    stopTimerImmediately();
    setError("Ending chat...");
    
  }, [room_id, sessionActive, connectionStatus, stopTimerImmediately]);

  /* ========= SELECTED USER INFO ========= */
  const selectedUser = useMemo(() => {
    if (!chatData) return null;

    if (userProfile) {
      return {
        id: userProfile.id,
        name: userProfile.full_name || userProfile.name || `User #${chatData.user_id}`,
        email: userProfile.email || '',
        phone: userProfile.phone || '',
        avatar: userProfile.profile_photo || `https://i.pravatar.cc/150?img=${chatData.user_id}`,
      };
    }

    return {
      id: chatData.user_id,
      name: `User #${chatData.user_id}`,
      avatar: `https://i.pravatar.cc/150?img=${chatData.user_id}`,
    };
  }, [chatData, userProfile]);

  /* ========= CALCULATE CURRENT EARNINGS ========= */
  const calculateEarnings = useMemo(() => {
    const perMinute = expertPrice?.chat_per_minute || chatData?.price_per_minute || 0;
    const completedMinutes = Math.ceil(displaySeconds / 60);
    return (perMinute * completedMinutes).toFixed(2);
  }, [expertPrice, chatData, displaySeconds]);

  /* ========= FORMAT SESSION TIME ========= */
  const formatSessionTime = useCallback(() => {
    const mins = Math.floor(displaySeconds / 60);
    const secs = displaySeconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  }, [displaySeconds]);

  if (loading && !isInitialized) {
    return (
      <PageWrap>
        <LoadingSpinner>
          <div>Loading chat...</div>
          <div style={{ fontSize: '12px', color: '#64748b', marginTop: '8px' }}>
            Socket: {connectionStatus}
          </div>
        </LoadingSpinner>
      </PageWrap>
    );
  }

  return (
    <PageWrap>
      <ChatLayout>
        <RightPanel style={{ width: "100%" }}>
          {chatData && selectedUser ? (
            <>
              <UserHeader>
                <UserInfo>
                  <Avatar src={selectedUser.avatar} />
                  <UserMeta>
                    <h4>{selectedUser.name}</h4>
                    {userProfileLoading ? (
                      <span>Loading user info...</span>
                    ) : userProfile ? (
                      <>
                        {selectedUser.email && <span>{selectedUser.email}</span>}
                        {selectedUser.phone && <span>{selectedUser.phone}</span>}
                      </>
                    ) : (
                      <span>User #{chatData.user_id}</span>
                    )}
                  </UserMeta>
                </UserInfo>

                <div style={{ textAlign: "right", display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  {/* Chat Status */}
                  <div
                    style={{
                      fontSize: 13,
                      fontWeight: 600,
                      color: sessionActive ? "#10b981" : "#ef4444",
                      display: "flex",
                      alignItems: "center",
                      gap: "4px",
                      justifyContent: "flex-end",
                    }}
                  >
                    {sessionActive ? "🟢 Chat Active" : "🔴 Chat Ended"}
                    {connectionStatus !== "connected" && (
                      <span style={{ fontSize: 11, color: '#f59e0b' }}>
                        ({connectionStatus})
                      </span>
                    )}
                  </div>

                  {/* Session Timer */}
                  <div
                    style={{
                      fontSize: 12,
                      color: sessionActive ? "#10b981" : "#6b7280",
                      fontWeight: sessionActive ? 600 : 400,
                    }}
                  >
                    Session: {formatSessionTime()}
                  </div>

                  {/* Earnings */}
                  <div
                    style={{
                      fontSize: 13,
                      color: "#111827",
                      fontWeight: 600,
                    }}
                  >
                    Earning: ₹{calculateEarnings}
                  </div>

                  {/* End Chat Button */}
                  {sessionActive && connectionStatus === "connected" && (
                    <button
                      onClick={handleEndChat}
                      disabled={!sessionActive || connectionStatus !== "connected"}
                      style={{
                        marginTop: '8px',
                        padding: '4px 12px',
                        background: sessionActive && connectionStatus === "connected" ? '#ef4444' : '#9ca3af',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        fontSize: '12px',
                        fontWeight: '600',
                        cursor: sessionActive && connectionStatus === "connected" ? 'pointer' : 'not-allowed',
                        alignSelf: 'flex-end'
                      }}
                    >
                      End Chat
                    </button>
                  )}
                </div>
              </UserHeader>

              {/* Error Message Display */}
              {error && (
                <div style={{
                  background: "#fef2f2",
                  color: "#ef4444",
                  padding: "10px 16px",
                  margin: "10px 16px",
                  borderRadius: "8px",
                  fontSize: "14px",
                  border: "1px solid #fecaca",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px"
                }}>
                  <FiUserX size={16} />
                  <span>{error}</span>
                  {error.includes("ended") && (
                    <span style={{ fontSize: "12px", color: "#9ca3af", marginLeft: 'auto' }}>
                      Redirecting to chat history...
                    </span>
                  )}
                </div>
              )}

              <ChatArea>
                <Messages>
                  {messages.length === 0 ? (
                    <EmptyChatMessage>
                      💬 Chat ready! Send first message or wait for user.
                      {connectionStatus !== "connected" && (
                        <div style={{ fontSize: '12px', color: '#f59e0b', marginTop: '8px' }}>
                          <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#f59e0b', animation: 'pulse 1s infinite', display: 'inline-block', marginRight: '4px' }} />
                          Connecting to chat server...
                        </div>
                      )}
                    </EmptyChatMessage>
                  ) : (
                    messages.map((msg, index) => (
                      <Message key={msg.id || msg.client_id || index} expert={msg.sender_type === "expert"}>
                        <Bubble expert={msg.sender_type === "expert"}>
                          <div>{msg.message}</div>
                          <span className="time">{msg.time}</span>
                          {msg.optimistic && (
                            <span style={{ marginLeft: '6px', fontSize: '10px', color: '#64748b' }}>🕐</span>
                          )}
                        </Bubble>
                      </Message>
                    ))
                  )}
                  <div ref={messagesEndRef} />
                </Messages>

                {/* Chat Input */}
                <ChatInputWrap>
                  <ChatInput
                    placeholder={
                      connectionStatus !== "connected" ? "Connecting..." :
                      !sessionActive ? "Chat session ended" :
                      "Type your response..."
                    }
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    disabled={!sessionActive || connectionStatus !== "connected"}
                    maxLength={1000}
                  />
                  <SendButton
                    onClick={handleSendMessage}
                    disabled={!message.trim() || !sessionActive || connectionStatus !== "connected"}
                  >
                    <FiSend size={18} />
                  </SendButton>
                </ChatInputWrap>
              </ChatArea>
            </>
          ) : error ? (
            <ErrorMessage>
              <FiUserX size={48} />
              <h3>{error}</h3>
              <p>Redirecting to chat history...</p>
              <button 
                onClick={() => navigate("/expert/chat-history")}
                style={{
                  marginTop: '16px',
                  padding: '10px 20px',
                  background: '#3b82f6',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontSize: '14px'
                }}
              >
                Go to Chat History Now
              </button>
            </ErrorMessage>
          ) : !isInitialized ? (
            <NoChatSelected>
              <FiClock size={48} />
              <h3>Initializing Chat...</h3>
              <p>Loading your chat session</p>
            </NoChatSelected>
          ) : (
            <NoChatSelected>
              <FiClock size={48} />
              <h3>No Chat Selected</h3>
              <p>Select a chat from your chat history</p>
            </NoChatSelected>
          )}
        </RightPanel>
      </ChatLayout>

      {/* Connection Status Indicator */}
      {connectionStatus !== "connected" && (
        <div style={{
          position: 'fixed',
          top: '10px',
          right: '10px',
          background: connectionStatus === "disconnected" ? '#f59e0b' : '#ef4444',
          color: 'white',
          padding: '8px 16px',
          borderRadius: '20px',
          fontSize: '12px',
          fontWeight: '600',
          zIndex: 1000,
          display: 'flex',
          alignItems: 'center',
          gap: '6px'
        }}>
          <div style={{
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            background: 'white',
            animation: 'pulse 1s infinite'
          }} />
          {connectionStatus === "disconnected" ? "Reconnecting..." : "Connection Error"}
        </div>
      )}

      <style jsx>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </PageWrap>
  );
};

export default ExpertChat;
