import React, { useEffect, useState, useCallback, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { socket } from "../../../../shared/api/socket";

import {
  PageWrapper,
  CallCard,
  StatusText,
  IncomingActions,
  ActionBtn,
  ExpertAvatarWrapper,
  ExpertAvatar,
  ExpertName,
  ExpertRole,
  Timer,
  Controls,
  ControlBtn,
  Brand,
} from "./ExpertVoiceCall.styles";
import {
  createPeer,
  closePeer,
  setRemote,
  addIce,
} from "../../../../shared/webrtc/voicePeer";



const DEFAULT_AVATAR = "https://i.pravatar.cc/300?img=44";

export default function ExpertVoiceCall() {
  const { callId } = useParams();
  const navigate = useNavigate();

  /**
   * incoming | connected | ended
   */
  const [callState, setCallState] = useState("incoming");
  const [seconds, setSeconds] = useState(0);
  const [muted, setMuted] = useState(false);

  const timerRef = useRef(null);

  /**
   * Caller meta (can be enriched later from backend)
   */
  const [caller] = useState({
    name: "Incoming Caller",
    role: "User",
    avatar: DEFAULT_AVATAR,
  });

  /* ===============================
     TIMER (CONNECTED ONLY)
  =============================== */
  useEffect(() => {
    if (callState === "connected") {
      timerRef.current = setInterval(() => {
        setSeconds((s) => s + 1);
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }

    return () => clearInterval(timerRef.current);
  }, [callState]);

  const formatTime = () => {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    return `${m}:${s}`;
  };

  /* ===============================
     SOCKET EVENTS
  =============================== */
  useEffect(() => {
    if (!callId) return;

    const handleCallConnected = () => {
      setCallState("connected");
    };

    const handleCallEnded = () => {
      setCallState("ended");

      setTimeout(() => {
        navigate("/expert/home", { replace: true });
      }, 1200);
    };

    socket.on("call:connected", handleCallConnected);
    socket.on("call:ended", handleCallEnded);

    return () => {
      socket.off("call:connected", handleCallConnected);
      socket.off("call:ended", handleCallEnded);
    };
  }, [callId, navigate]);

  /* ===============================
     ACTIONS
  =============================== */
  const acceptCall = useCallback(() => {
    if (!callId) return;
    socket.emit("call:accept", { callId });
    setCallState("connected");
  }, [callId]);

 useEffect(() => {
  if (!callId) return;

  const onOffer = async ({ callId: incomingCallId, offer }) => {
    console.log("📡 Offer received for call:", incomingCallId);

    const pc = await createPeer(socket, false);

    await setRemote(offer);

    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);

    socket.emit("webrtc:answer", {
      callId: incomingCallId,
      answer,
    });

    setCallState("connected");
  };

  const onIce = ({ callId: iceCallId, candidate }) => {
    if (iceCallId !== callId) return;
    addIce(candidate);
  };

  socket.on("webrtc:offer", onOffer);
  socket.on("webrtc:ice", onIce);

  return () => {
    socket.off("webrtc:offer", onOffer);
    socket.off("webrtc:ice", onIce);
  };
}, [callId]);


  const rejectCall = useCallback(() => {
    if (!callId) return;

    socket.emit("call:reject", { callId });
    setCallState("ended");

    setTimeout(() => {
      navigate("/expert/home", { replace: true });
    }, 1000);
  }, [callId, navigate]);

  const endCall = useCallback(() => {
    if (!callId) return;

    socket.emit("call:end", { callId });
    setCallState("ended");

    setTimeout(() => {
      navigate("/expert/home", { replace: true });
    }, 1000);
  }, [callId, navigate]);

  /* ===============================
     RENDER
  =============================== */
  return (
    <PageWrapper>
      <CallCard>
        {/* AVATAR */}
        <ExpertAvatarWrapper>
          <ExpertAvatar src={caller.avatar} />
        </ExpertAvatarWrapper>

        <ExpertName>{caller.name}</ExpertName>
        <ExpertRole>{caller.role}</ExpertRole>

        {/* INCOMING */}
        {callState === "incoming" && (
          <>
            <StatusText>INCOMING VOICE CALL</StatusText>
            <IncomingActions>
              <ActionBtn accept onClick={acceptCall}>
                ✔ Accept
              </ActionBtn>
              <ActionBtn onClick={rejectCall}>
                ✕ Reject
              </ActionBtn>
            </IncomingActions>
          </>
        )}

        {/* CONNECTED */}
        {callState === "connected" && (
          <>
            <Timer>{formatTime()}</Timer>

            <Controls>
              <ControlBtn
                active={muted}
                onClick={() => setMuted((m) => !m)}
              >
                {muted ? "🔇" : "🎤"}
                <span>Mute</span>
              </ControlBtn>

              <ControlBtn danger onClick={endCall}>
                ❌
                <span>End</span>
              </ControlBtn>
            </Controls>
          </>
        )}

        {/* ENDED */}
        {callState === "ended" && (
          <StatusText>CALL ENDED</StatusText>
        )}

        <Brand>🌿 EXPERT YARD — Expert Panel</Brand>
      </CallCard>
    </PageWrapper>
  );
}
