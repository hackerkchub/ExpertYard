// src/apps/user/pages/chat/Chat.jsx - ✅ FULLY UPDATED for Server Socket Compatibility
import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { FiPaperclip, FiImage, FiVideo, FiFile, FiX } from "react-icons/fi";
import { IoMdSend } from "react-icons/io";
import {
  PageWrap,
  Header,
  ExpertInfo,
  Avatar,
  AvatarWrapper,
  StatusDot,
  MessagesArea,
  MessageRow,
  MessageBubble,
  InputBar,
  InputBox,
  SendButton,
  MessageTime,
  FileUploadMenu,
  UploadButton,
  ChatGlobalStyle,
  LoadingSpinner,
  ErrorMessage,
  EndChatButton,
  EmptyChatMessage,
} from "./Chat.styles";

import { socket } from "../../../../shared/api/socket";
import { useAuth } from "../../../../shared/context/UserAuthContext";
import { useExpert } from "../../../../shared/context/ExpertContext";

const Chat = () => {
  const { room_id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [input, setInput] = useState("");
  const [showFileMenu, setShowFileMenu] = useState(false);
  const [messages, setMessages] = useState([]);
  const [chatData, setChatData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [sessionActive, setSessionActive] = useState(true);
  const [isInitialized, setIsInitialized] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState("connecting");
  const [userId, setUserId] = useState(null);
  const [showEndChatConfirm, setShowEndChatConfirm] = useState(false);
  
  const scrollRef = useRef(null);
  const pendingMessages = useRef(new Map());
  const messageQueue = useRef([]);
  const isProcessingQueue = useRef(false);
  const seenMessageIds = useRef(new Set());
  const hasLeftChat = useRef(false);
  const redirectTimeoutRef = useRef(null);
  const previousPathRef = useRef(location.pathname);
  const isRegisteredRef = useRef(false);
  
  const { user } = useAuth();
  const { experts, expertData } = useExpert();

  // ✅ **1. Set user ID from auth**
  useEffect(() => {
    if (user?.id) {
      const id = Number(user.id);
      setUserId(id);
      localStorage.setItem('user_id', id.toString());
      console.log("👤 User ID set:", id);
    } else {
      // Fallback to localStorage
      const storedUserId = localStorage.getItem('user_id');
      const storedUser = JSON.parse(localStorage.getItem('user') || '{}');
      
      if (storedUserId) {
        setUserId(Number(storedUserId));
        console.log("👤 User ID from localStorage:", storedUserId);
      } else if (storedUser.id) {
        const id = Number(storedUser.id);
        setUserId(id);
        localStorage.setItem('user_id', id.toString());
        console.log("👤 User ID from stored user:", id);
      } else {
        console.log("❌ No user found, redirecting to login");
        navigate('/login');
      }
    }
  }, [user, navigate]);



  // ✅ **5. Chat details fetch**
  const fetchChatDetails = useCallback(async () => {
    if (!room_id || !userId) {
      console.log("⏳ fetchChatDetails: missing room_id/userId", { room_id, userId });
      setLoading(false);
      setIsInitialized(true);
      return;
    }
    
    try {
      setLoading(true);
      const token = localStorage.getItem('user_token');
      
      console.log("📡 Fetching chat details for room:", room_id);
      const response = await fetch(`/api/chat/details/${room_id}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Chat session not found');
        }
        throw new Error(`HTTP ${response.status}`);
      }
      
      const result = await response.json();
      
      console.log("📊 Chat details response:", result);
      
      if (!result.success || !result.data?.session) {
        throw new Error(result.message || 'Invalid chat data');
      }
      
      const { session, messages: fetchedMessages } = result.data;
      
      // ✅ Type conversion
      const sessionUserId = Number(session.user_id);
      if (sessionUserId !== Number(userId)) {
        throw new Error(`Not authorized for room ${room_id}`);
      }
      
      setChatData(session);
      setSessionActive(session.is_active === 1 || session.is_active === true);
      
      const uniqueMessages = (fetchedMessages || []).map(msg => ({
        id: msg.id,
        sender_type: msg.sender_type,
        sender_id: msg.sender_id,
        message: msg.message,
        room_id: room_id,
        time: new Date(msg.created_at).toLocaleTimeString('en-US', { 
          hour: '2-digit', minute: '2-digit', hour12: true 
        })
      }));
      
      setMessages(uniqueMessages);
      setError("");
      
      console.log(`✅ Chat loaded: ${uniqueMessages.length} messages, active: ${session.is_active}`);
      
    } catch (err) {
      console.error("❌ Chat fetch error:", err);
      setError(err.message);
      setSessionActive(false);
    } finally {
      setLoading(false);
      setIsInitialized(true);
    }
  }, [room_id, userId]);

  // ✅ **6. Handle chat started event from server**
  const handleChatStarted = useCallback(({ room_id: startedRoomId, user_id }) => {
    if (startedRoomId === room_id) {
      console.log("🚀 Chat started event received:", startedRoomId);
      setSessionActive(true);
      setError("");
      // Refresh chat details
      setTimeout(() => fetchChatDetails(), 500);
    }
  }, [room_id, fetchChatDetails]);

  // ✅ **7. Handle chat ended - WITH PROPER REDIRECT TO CHAT HISTORY**
  const handleChatEnded = useCallback(({ room_id: endedRoomId, reason }) => {
    if (endedRoomId === room_id) {
      console.log("🔴 Chat ended:", reason);
      
      setSessionActive(false);
      hasLeftChat.current = true;
      
      let errorMsg = "Chat session ended";
      if (reason === "Expert ended chat") {
        errorMsg = "Expert ended the chat";
      } else if (reason === "Insufficient balance") {
        errorMsg = "Insufficient balance - Chat ended";
      } else if (reason?.includes("disconnected")) {
        errorMsg = "Connection lost - Chat ended";
      } else if (reason === "User ended chat") {
        errorMsg = "Chat ended by user";
      }
      
      setError(errorMsg);
      
      // Clear any existing timeout
      if (redirectTimeoutRef.current) {
        clearTimeout(redirectTimeoutRef.current);
      }
      
      // ✅ Auto redirect to chat history after 2 seconds
      redirectTimeoutRef.current = setTimeout(() => {
        navigate("/user/chat-history", { 
          replace: true,
          state: { 
            recentChatEnded: true,
            room_id: room_id,
            reason: reason 
          }
        });
      }, 2000);
    }
  }, [room_id, navigate]);

  // ✅ **8. Manual end chat - User initiated**
  const handleEndChat = useCallback(() => {
    if (!room_id || !sessionActive) return;
    setShowEndChatConfirm(true);
  }, [room_id, sessionActive]);

  // ✅ **9. Confirm end chat - Emit event to server and redirect**
  const confirmEndChat = useCallback(() => {
    if (hasLeftChat.current) return;

    console.log("🔚 User manually ended chat");
    
    setShowEndChatConfirm(false);
    setSessionActive(false);
    hasLeftChat.current = true;
    
    // Emit end_chat event to server
    socket.emit("end_chat", { 
      room_id
      // Server socket.identity से user_id और role लेगा
    });
    
    // Clear any existing timeout
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
    }
    
    // Redirect after 2 seconds
    redirectTimeoutRef.current = setTimeout(() => {
      navigate("/user/chat-history", { 
        replace: true,
        state: { 
          recentChatEnded: true,
          room_id: room_id,
          ended_by: 'user'
        }
      });
    }, 2000);
  }, [room_id, navigate]);

  // ✅ **10. Process message queue**
  const processMessageQueue = useCallback(() => {
    if (isProcessingQueue.current || messageQueue.current.length === 0) return;
    
    isProcessingQueue.current = true;
    
    while (messageQueue.current.length > 0) {
      const msgData = messageQueue.current.shift();
      
      // ✅ Duplicate check
      if (msgData.id && seenMessageIds.current.has(msgData.id)) {
        continue;
      }
      
      const newMessage = {
        id: msgData.id,
        sender_type: msgData.sender_type,
        sender_id: msgData.sender_id,
        message: msgData.message,
        room_id: msgData.room_id,
        time: new Date(msgData.time || Date.now()).toLocaleTimeString('en-US', { 
          hour: '2-digit', minute: '2-digit', hour12: true 
        })
      };
      
      if (newMessage.id) {
        seenMessageIds.current.add(newMessage.id);
      }
      
      setMessages(prev => [...prev, newMessage]);
    }
    
    isProcessingQueue.current = false;
  }, []);

  // ✅ **11. Handle new message from server**
  const handleNewMessage = useCallback((msgData) => {
    console.log("📩 New message received:", msgData);
    
    if (msgData.room_id !== room_id) return;
    
    messageQueue.current.push(msgData);
    
    setTimeout(() => {
      processMessageQueue();
    }, 0);
  }, [room_id, processMessageQueue]);

  // ✅ **12. Handle message sent confirmation**
  const handleMessageSent = useCallback((msgData) => {
    console.log("✅ Message sent confirmation:", msgData);
    
    if (msgData.room_id !== room_id) return;
    
    if (msgData.client_id && pendingMessages.current.has(msgData.client_id)) {
      pendingMessages.current.delete(msgData.client_id);
    }
    
    setMessages(prev => prev.map(msg => 
      msg.client_id === msgData.client_id 
        ? { 
            ...msg, 
            id: msgData.id, 
            time: new Date(msgData.time || Date.now()).toLocaleTimeString('en-US', { 
              hour: '2-digit', minute: '2-digit', hour12: true 
            }), 
            optimistic: false 
          }
        : msg
    ));
    
    if (msgData.id) {
      seenMessageIds.current.add(msgData.id);
    }
  }, [room_id]);

  // ✅ **13. Handle chat update (balance deduction, etc.)**
  const handleChatUpdate = useCallback(({ room_id: updatedRoomId }) => {
    if (updatedRoomId === room_id) {
      console.log("🔄 Chat updated");
      // You can show a notification or update UI here
    }
  }, [room_id]);

  // ✅ **14. Handle socket disconnect**
  const handleSocketDisconnect = useCallback(() => {
    console.log("🔴 Socket disconnected");
    setConnectionStatus("disconnected");
    isRegisteredRef.current = false;
  }, []);

  // ✅ **15. Handle connection errors**
  const handleConnectError = useCallback((err) => {
    console.error("❌ Socket connect_error:", err);
    setConnectionStatus("error");
    isRegisteredRef.current = false;
  }, []);

  // ✅ **16. Handle socket errors from server**
  const handleSocketError = useCallback((errorMessage) => {
    console.error("❌ Socket error:", errorMessage);
    setError(errorMessage);
    
    if (errorMessage.includes("Unauthorized") || 
        errorMessage.includes("Not a participant") ||
        errorMessage.includes("Not authorized")) {
      setTimeout(() => {
        navigate("/user/dashboard");
      }, 2000);
    } else if (errorMessage.includes("No active session") || 
               errorMessage.includes("Chat session not found")) {
      setSessionActive(false);
    }
  }, [navigate]);

  // ✅ **17. MAIN SOCKET SETUP - Pure consumer**
  useEffect(() => {
    if (!room_id || !userId) return;
    
    console.log("🔧 Setting up socket listeners for room:", room_id);
    
    // Socket listeners
    socket.on("disconnect", handleSocketDisconnect);
    socket.on("connect_error", handleConnectError);
    socket.on("error", handleSocketError);
    
    // Chat listeners
    socket.on("chat_started", handleChatStarted);
    socket.on("message", handleNewMessage);
    socket.on("message_sent", handleMessageSent);
    socket.on("chat_updated", handleChatUpdate);
    socket.on("chat_ended", handleChatEnded);
    
    console.log("🎯 Socket listeners registered - Ready for chat");
    
    return () => {
      console.log("🧹 Cleaning up socket listeners");
      
      socket.off("disconnect", handleSocketDisconnect);
      socket.off("connect_error", handleConnectError);
      socket.off("error", handleSocketError);
      
      socket.off("chat_started", handleChatStarted);
      socket.off("message", handleNewMessage);
      socket.off("message_sent", handleMessageSent);
      socket.off("chat_updated", handleChatUpdate);
      socket.off("chat_ended", handleChatEnded);
      
      // Cleanup redirect timeout
      if (redirectTimeoutRef.current) {
        clearTimeout(redirectTimeoutRef.current);
      }
    };
  }, [
    room_id, 
    userId,
    handleSocketDisconnect,
    handleConnectError,
    handleSocketError,
    handleChatStarted,
    handleNewMessage, 
    handleMessageSent, 
    handleChatUpdate, 
    handleChatEnded
  ]);
 
  // ✅ **20. Expert information**
  const expertInfo = useMemo(() => {
    if (!chatData?.expert_id) return null;
    
    if (expertData?.expertId === chatData.expert_id) {
      return {
        name: expertData.name || `Expert #${chatData.expert_id}`,
        position: expertData.position || '',
        avatar: expertData.profile_photo || `https://i.pravatar.cc/150?img=${chatData.expert_id}`,
      };
    }
    
    const expert = experts.find(e => e.id == chatData.expert_id);
    if (expert) {
      return {
        name: expert.name,
        position: expert.position || '',
        avatar: expert.profile_photo || `https://i.pravatar.cc/150?img=${chatData.expert_id}`,
      };
    }
    
    return {
      name: `Expert #${chatData.expert_id}`,
      position: '',
      avatar: `https://i.pravatar.cc/150?img=${chatData.expert_id}`,
    };
  }, [chatData?.expert_id, experts, expertData]);

  // ✅ **21. Auto-scroll to latest message**
  useEffect(() => {
    if (messages.length > 0) {
      const timer = setTimeout(() => {
        scrollRef.current?.scrollIntoView({ 
          behavior: "smooth", 
          block: "end" 
        });
      }, 100);
      
      return () => clearTimeout(timer);
    }
  }, [messages]);

  // ✅ **22. Initial load - fetch chat details**
  useEffect(() => {
    if (!userId || !room_id) return;
    
    console.log("📥 Initial chat load for room:", room_id);
    fetchChatDetails();
    
    // Poll for updates every 30 seconds
    const interval = setInterval(fetchChatDetails, 30000);
    return () => clearInterval(interval);
  }, [fetchChatDetails, userId, room_id]);

  // ✅ **23. Send message**
  const sendMessage = useCallback(() => {
    if (!input.trim() || !sessionActive || connectionStatus !== "connected") {
      console.log("❌ Send message blocked:", {
        hasInput: !!input.trim(),
        sessionActive,
        connectionStatus
      });
      return;
    }

    const clientId = `client_${Date.now()}_${Math.random().toString(36).slice(2)}`;

    // Optimistic UI update
    const optimisticMessage = {
      id: null,
      client_id: clientId,
      sender_type: "user",
      sender_id: userId,
      message: input.trim(),
      room_id: room_id,
      time: new Date().toLocaleTimeString('en-US', { 
        hour: '2-digit', minute: '2-digit', hour12: true 
      }),
      optimistic: true
    };

    // Store in pending messages
    pendingMessages.current.set(clientId, optimisticMessage);
    
    // Update UI immediately
    setMessages(prev => [...prev, optimisticMessage]);
    setInput("");

    // Send to server - CORRECT FORMAT (सिर्फ ये 3 fields)
    socket.emit("sendMessage", {
      room_id: room_id,
      message: input.trim(),
      client_id: clientId
      // ✅ Server को sender_type और sender_id socket.identity से मिल जाएगा
    });

    console.log("📤 Message sent to server:", { 
      room_id, 
      clientId,
      message: input.trim()
    });

  }, [input, sessionActive, connectionStatus, userId, room_id]);

  // ✅ **24. Enter key handler**
  const handleKeyPress = useCallback((e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }, [sendMessage]);

  // ✅ **25. Get status text**
  const getStatusText = () => {
    if (connectionStatus === "connecting") return "🔄 Connecting...";
    if (connectionStatus === "disconnected") return "🔌 Disconnected";
    if (connectionStatus === "error") return "❌ Connection Error";
    if (!sessionActive) return '🔴 Ended';
    return '🟢 Active';
  };

  // ✅ **26. Get status color**
  const getStatusColor = () => {
    if (connectionStatus === "connecting") return '#f59e0b';
    if (connectionStatus === "disconnected") return '#ef4444';
    if (connectionStatus === "error") return '#ef4444';
    if (!sessionActive) return '#ef4444';
    return '#10b981';
  };

  // ✅ **27. Handle retry connection**
  const retryConnection = useCallback(() => {
    console.log("🔄 Retrying connection...");
    setConnectionStatus("connecting");
    isRegisteredRef.current = false;
    
    // Trigger reconnection
   
  }, []);

  // ✅ **28. Debug: Log socket state**
  useEffect(() => {
    console.log("🔍 Chat Component State:", {
      userId,
      room_id,
      connectionStatus,
      sessionActive,
      messagesCount: messages.length,
      loading,
      error
    });
  }, [userId, room_id, connectionStatus, sessionActive, messages.length, loading, error]);

  if (loading && !isInitialized) {
    return (
      <>
        <ChatGlobalStyle />
        <PageWrap>
          <LoadingSpinner>
            <div>Loading chat session...</div>
            <div style={{ fontSize: '12px', color: '#64748b', marginTop: '8px' }}>
              Socket: {connectionStatus}
            </div>
            {connectionStatus === "error" && (
              <button 
                onClick={retryConnection}
                style={{
                  marginTop: '16px',
                  padding: '8px 16px',
                  background: '#3b82f6',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '12px'
                }}
              >
                Retry Connection
              </button>
            )}
          </LoadingSpinner>
        </PageWrap>
      </>
    );
  }

  return (
    <>
      <ChatGlobalStyle />
      <PageWrap>
        {/* Connection Status Indicator */}
        {connectionStatus !== "connected" && (
          <div style={{
            position: 'fixed',
            top: '10px',
            right: '10px',
            background: connectionStatus === "error" ? '#ef4444' : 
                      connectionStatus === "connecting" ? '#f59e0b' : '#64748b',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '20px',
            fontSize: '12px',
            fontWeight: '600',
            zIndex: 1000,
            display: 'flex',
            alignItems: 'center',
            gap: '6px'
          }}>
            <div style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: 'white',
              animation: 'pulse 1s infinite'
            }} />
            {connectionStatus === "connecting" && "Connecting..."}
            {connectionStatus === "disconnected" && "Reconnecting..."}
            {connectionStatus === "error" && "Connection Error"}
            
            {(connectionStatus === "error" || connectionStatus === "disconnected") && (
              <button 
                onClick={retryConnection}
                style={{
                  marginLeft: '8px',
                  padding: '4px 8px',
                  background: 'rgba(255,255,255,0.2)',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '10px'
                }}
              >
                Retry
              </button>
            )}
          </div>
        )}

        <Header>
          {chatData && expertInfo ? (
            <>
              <ExpertInfo>
                <AvatarWrapper>
                  <Avatar src={expertInfo.avatar} alt={expertInfo.name} />
                  <StatusDot active={sessionActive && connectionStatus === "connected"} />
                </AvatarWrapper>
                <div>
                  <div className="expert-name">
                    {expertInfo.name}
                    {expertInfo.position && (
                      <span style={{ fontSize: '0.85em', color: '#64748b', marginLeft: '8px' }}>
                        • {expertInfo.position}
                      </span>
                    )}
                  </div>
                  <div className="status">
                    <span style={{ 
                      color: getStatusColor(),
                      fontWeight: '500'
                    }}>
                      {getStatusText()}
                    </span>
                  </div>
                </div>
              </ExpertInfo>
              <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
                {/* Price per minute */}
                {chatData.price_per_minute && (
                  <div style={{
                    background: "#e0f2fe",
                    color: "#0369a1",
                    padding: "6px 10px",
                    borderRadius: "6px",
                    fontSize: "12px",
                    fontWeight: "600"
                  }}>
                    ₹{chatData.price_per_minute}/min
                  </div>
                )}
                
                {/* End Chat Button */}
                <EndChatButton
                  onClick={handleEndChat}
                  disabled={!sessionActive || connectionStatus !== "connected"}
                  title="End chat"
                >
                  <FiX size={20} />
                </EndChatButton>
              </div>
            </>
          ) : (
            <div style={{ color: "#64748b", padding: "20px" }}>Loading...</div>
          )}
        </Header>

        <MessagesArea>
          {error ? (
            <ErrorMessage>
              <FiX size={48} />
              <h3>{error}</h3>
              <p>Redirecting to chat history...</p>
              <button 
                onClick={() => navigate("/user/chat-history")}
                style={{
                  marginTop: '16px',
                  padding: '10px 20px',
                  background: '#3b82f6',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: '600'
                }}
              >
                Go to Chat History Now
              </button>
            </ErrorMessage>
          ) : messages.length === 0 ? (
            <EmptyChatMessage>
              <div style={{ fontSize: "48px", marginBottom: "16px" }}>💬</div>
              <h3>Start a conversation</h3>
              <p>You're now connected with {expertInfo?.name || 'the expert'}. Say hello!</p>
              
              {connectionStatus !== "connected" && (
                <div style={{ 
                  fontSize: '14px', 
                  color: '#f59e0b', 
                  marginTop: '12px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px'
                }}>
                  <div style={{
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    background: '#f59e0b',
                    animation: 'pulse 1s infinite'
                  }} />
                  {connectionStatus === "connecting" ? "Connecting to chat server..." : 
                   connectionStatus === "disconnected" ? "Reconnecting..." : 
                   "Connection error, please refresh"}
                </div>
              )}
            </EmptyChatMessage>
          ) : (
            <>
              {messages.map((msg, index) => (
                <MessageRow 
                  key={msg.id || msg.client_id || index} 
                  className={msg.sender_type}
                >
                  <MessageBubble 
                    className={msg.sender_type}
                    style={msg.optimistic ? { opacity: 0.7, background: msg.sender_type === 'user' ? '#e0f2fe' : '#f1f5f9' } : {}}
                  >
                    <div className="message-text">{msg.message}</div>
                    <MessageTime>
                      {msg.time}
                      {msg.optimistic && (
                        <span style={{ marginLeft: '6px', fontSize: '10px', color: '#64748b' }}>🕐</span>
                      )}
                    </MessageTime>
                  </MessageBubble>
                </MessageRow>
              ))}
            </>
          )}
          <div ref={scrollRef} />
        </MessagesArea>

        <InputBar>
          {/* File Upload */}
          <UploadButton 
            onClick={() => setShowFileMenu(!showFileMenu)} 
            disabled={!sessionActive || connectionStatus !== "connected"}
            title="Attach files"
          >
            <FiPaperclip size={20} />
          </UploadButton>

          {showFileMenu && (
            <FileUploadMenu>
              <div className="menu-item" onClick={() => setShowFileMenu(false)}>
                <FiImage size={18} /><span>Photos</span>
              </div>
              <div className="menu-item" onClick={() => setShowFileMenu(false)}>
                <FiVideo size={18} /><span>Videos</span>
              </div>
              <div className="menu-item" onClick={() => setShowFileMenu(false)}>
                <FiFile size={18} /><span>Documents</span>
              </div>
            </FileUploadMenu>
          )}

          {/* Message Input */}
          <InputBox
            placeholder={
              connectionStatus === "connecting" ? "Connecting to server..." :
              connectionStatus === "disconnected" ? "Connection lost, reconnecting..." :
              connectionStatus === "error" ? "Connection error, please refresh" :
              !sessionActive ? "Chat ended" :
              "Type your message..."
            }
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyPress}
            disabled={
              !sessionActive || 
              connectionStatus !== "connected" ||
              loading
            }
            maxLength={1000}
            rows={1}
          />

          {/* Send Button */}
          <SendButton 
            onClick={sendMessage} 
            disabled={
              !input.trim() || 
              !sessionActive || 
              connectionStatus !== "connected" ||
              loading
            }
            title="Send message"
          >
            <IoMdSend size={20} />
          </SendButton>
        </InputBar>

        {/* End Chat Confirmation */}
        {showEndChatConfirm && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.7)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 9999
          }}>
            <div style={{
              background: 'white',
              padding: '30px',
              borderRadius: '16px',
              maxWidth: '400px',
              width: '90%',
              textAlign: 'center'
            }}>
              <FiX size={48} style={{ color: '#ef4444', marginBottom: '20px' }} />
              <h2 style={{ color: '#1e293b', marginBottom: '12px' }}>
                End Chat?
              </h2>
              <p style={{ color: '#64748b', marginBottom: '28px' }}>
                Are you sure you want to end this chat session?<br />
                <small style={{ fontSize: '12px', color: '#94a3b8' }}>
                  This will stop further charges
                </small>
              </p>
              <div style={{ display: 'flex', gap: '12px' }}>
                <button 
                  onClick={() => setShowEndChatConfirm(false)}
                  style={{
                    background: '#e2e8f0',
                    color: '#475569',
                    border: 'none',
                    padding: '12px 24px',
                    borderRadius: '8px',
                    fontSize: '16px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    flex: 1
                  }}
                >
                  Cancel
                </button>
                <button 
                  onClick={confirmEndChat}
                  style={{
                    background: '#ef4444',
                    color: 'white',
                    border: 'none',
                    padding: '12px 24px',
                    borderRadius: '8px',
                    fontSize: '16px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    flex: 1
                  }}
                >
                  End Chat
                </button>
              </div>
            </div>
          </div>
        )}
      </PageWrap>

      <style jsx="true">{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </>
  );
};

export default Chat;