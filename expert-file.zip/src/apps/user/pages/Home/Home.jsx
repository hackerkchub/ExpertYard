// src/apps/user/pages/Home/HomePage.jsx
import React from "react";
import { useNavigate } from "react-router-dom";

import Slider from "../../components/HomeSlider/HomeSlider";
import Categories from "../../components/HomeComponent/Categories";

// NEW COMPONENTS
import Hero from "../../components/HomeComponent/Hero";
import Experts from "../../components/HomeComponent/Experts";
import HowItWorks from "../../components/HomeComponent/HowItWorks";
import Testimonials from "../../components/HomeComponent/Testimonials";
import "./Home.css";

import { FiUserCheck, FiMessageCircle } from "react-icons/fi";

const HomePage = () => {
  const navigate = useNavigate();

  return (
    <>
      <Hero />
      
      <div className="section-wrapper">
        <div className="section-header">
          <h2>Categories</h2>
          <button 
            className="view-all-btn"
            onClick={() => navigate('/user/categories')}
          >
            View All Categories
          </button>
        </div>
        <Categories />
      </div>
      
        <Experts />
     

      <HowItWorks />
      <Testimonials />
    </>
  );
};

export default HomePage;