import React, { useEffect, useState, useRef, useMemo, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";

import {
  PageWrapper,
  CallCard,
  TopSection,
  UserBlock,
  Avatar,
  Name,
  CallIconRing,
  StatusText,
  EndCallButton,
  ExpertSection,
  ExpertAvatarWrapper,
  ExpertAvatar,
  ExpertName,
  ExpertRole,
  ConnectingBar,
  Brand,
  Controls,
  ControlBtn,
  Timer,
} from "./VoiceCall.styles";

import { useExpert } from "../../../../shared/context/ExpertContext";
import { socket } from "../../../../shared/api/socket";
import {
  createPeer,
  closePeer,
  setRemote,
  addIce,
} from "../../../../shared/webrtc/voicePeer";

const DEFAULT_AVATAR = "https://i.pravatar.cc/300?img=44";

export default function VoiceCall() {
  const { expertId } = useParams();
  const navigate = useNavigate();
  const { experts } = useExpert();

  // ✅ Refs to prevent duplicate listeners
  const socketAttached = useRef(false);
  const peerCreated = useRef(false);
  const callIdRef = useRef(null);

  /* ===============================
     FIND EXPERT DATA
  =============================== */
  const expert = useMemo(() => {
    if (!expertId || !experts?.length) return null;
    return experts.find(
      (e) => Number(e.id) === Number(expertId)
    );
  }, [experts, expertId]);

  /**
   * calling | connected | busy | offline | ended
   */
  const [callState, setCallState] = useState("calling");
  const [callId, setCallId] = useState(null);

  /* TIMER */
  const [seconds, setSeconds] = useState(0);
  const timerRef = useRef(null);

  /* CONTROLS */
  const [muted, setMuted] = useState(false);
  const [speaker, setSpeaker] = useState(false);

  // ✅ Store callId in ref for cleanup
  useEffect(() => {
    callIdRef.current = callId;
  }, [callId]);

  /* ===============================
     ✅ CORRECT WEBRTC FLOW
     (ONLY after call:connected event)
  =============================== */
  const handleWebRTCOffer = useCallback(async (currentCallId) => {
    if (!currentCallId || peerCreated.current) return;

    console.log("📡 Creating WebRTC offer for call:", currentCallId);
    
    try {
      const pc = await createPeer(socket, currentCallId);
      peerCreated.current = true;

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      socket.emit("webrtc:offer", {
        callId: currentCallId,
        offer,
      });

      console.log("✅ Offer sent to expert");
    } catch (err) {
      console.error("❌ WebRTC offer failed:", err);
      setCallState("ended");
    }
  }, []);

  /* ===============================
     ✅ SOCKET EVENTS - ATTACH ONCE
  =============================== */
  useEffect(() => {
    if (socketAttached.current) return;

    console.log("📡 Setting up voice call listeners");

    // ✅ 1. Call connected - START WEBRTC HERE
    const onConnected = ({ callId: connectedCallId }) => {
      console.log("✅ Call connected:", connectedCallId);
      setCallId(connectedCallId);
      setCallState("connected");
      
      // ✅ START WEBRTC NEGOTIATION HERE (only after connected)
      handleWebRTCOffer(connectedCallId);
    };

    // ✅ 2. WebRTC Answer from expert
    const onWebRTCAnswer = async ({ callId: answerCallId, answer }) => {
      console.log("📡 WebRTC Answer received for call:", answerCallId);
      
      if (answerCallId !== callIdRef.current) return;
      
      try {
        await setRemote(answer);
        console.log("✅ Remote description set");
      } catch (err) {
        console.error("❌ Failed to set remote:", err);
      }
    };

    // ✅ 3. ICE Candidates
    const onWebRTCIce = ({ callId: iceCallId, candidate }) => {
      if (iceCallId !== callIdRef.current) return;
      addIce(candidate);
    };

    // ✅ 4. Other call events
    const onBusy = () => {
      console.log("🚫 Expert busy");
      setCallState("busy");
    };

    const onOffline = () => {
      console.log("🔴 Expert offline");
      setCallState("offline");
    };

    const onEnded = ({ reason }) => {
      console.log("❌ Call ended:", reason);
      setCallState("ended");
      closePeer();
      peerCreated.current = false;
    };

    // Attach all listeners
    socket.on("call:connected", onConnected);
    socket.on("webrtc:answer", onWebRTCAnswer);
    socket.on("webrtc:ice", onWebRTCIce);
    socket.on("call:busy", onBusy);
    socket.on("call:offline", onOffline);
    socket.on("call:ended", onEnded);

    socketAttached.current = true;

    return () => {
      console.log("🧹 Cleaning up voice call listeners");
      
      socket.off("call:connected", onConnected);
      socket.off("webrtc:answer", onWebRTCAnswer);
      socket.off("webrtc:ice", onWebRTCIce);
      socket.off("call:busy", onBusy);
      socket.off("call:offline", onOffline);
      socket.off("call:ended", onEnded);
      
      socketAttached.current = false;
      
      // Cleanup WebRTC
      closePeer();
      peerCreated.current = false;
    };
  }, [handleWebRTCOffer]);

  /* ===============================
     TIMER
  =============================== */
  useEffect(() => {
    if (callState === "connected") {
      timerRef.current = setInterval(() => {
        setSeconds((s) => s + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [callState]);

  const formatTime = () => {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    return `${m}:${s}`;
  };

  /* ===============================
     END CALL
  =============================== */
  const handleEnd = useCallback(() => {
    console.log("🔚 Ending call:", callIdRef.current);
    
    if (callIdRef.current) {
      socket.emit("call:end", { callId: callIdRef.current });
    }
    
    closePeer();
    peerCreated.current = false;
    navigate(-1);
  }, [navigate]);

  // ✅ Auto-navigate when call ends
  useEffect(() => {
    if (callState === "ended") {
      const timer = setTimeout(() => {
        navigate(-1);
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [callState, navigate]);

  // ✅ Auto-navigate on busy/offline
  useEffect(() => {
    if (callState === "busy" || callState === "offline") {
      const timer = setTimeout(() => {
        navigate(-1);
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [callState, navigate]);

  /* ===============================
     UI RENDER
  =============================== */
  return (
    <PageWrapper>
      <CallCard>
        <TopSection>
          <UserBlock>
            <Avatar src="https://randomuser.me/api/portraits/men/32.jpg" />
            <Name>YOU</Name>
          </UserBlock>

          {callState === "calling" && (
            <CallIconRing>
              <span>📞</span>
            </CallIconRing>
          )}
        </TopSection>

        {callState === "calling" && (
          <>
            <StatusText>CALLING {expert?.name || "EXPERT"}...</StatusText>
            <EndCallButton onClick={handleEnd}>
              ✕ <span>Cancel</span>
            </EndCallButton>
          </>
        )}

        {callState === "connected" && (
          <>
            <Timer>{formatTime()}</Timer>

            <Controls>
              <ControlBtn active={muted} onClick={() => setMuted(m => !m)}>
                {muted ? "🔇" : "🎤"}
                <span>Mute</span>
              </ControlBtn>

              <ControlBtn active={speaker} onClick={() => setSpeaker(s => !s)}>
                🔊
                <span>Speaker</span>
              </ControlBtn>

              <ControlBtn danger onClick={handleEnd}>
                ❌
                <span>End</span>
              </ControlBtn>
            </Controls>
          </>
        )}

        {(callState === "busy" || callState === "offline") && (
          <>
            <StatusText>
              {callState === "busy" ? "EXPERT IS BUSY" : "EXPERT IS OFFLINE"}
            </StatusText>
            <EndCallButton onClick={() => navigate(-1)}>
              ✕ <span>Back</span>
            </EndCallButton>
          </>
        )}

        {callState !== "ended" && callState !== "busy" && callState !== "offline" && (
          <ExpertSection>
            <ExpertAvatarWrapper>
              <ExpertAvatar src={expert?.profile_photo || DEFAULT_AVATAR} />
            </ExpertAvatarWrapper>

            <ExpertName>{expert?.name || "Expert"}</ExpertName>
            <ExpertRole>{expert?.position || "Advisor"}</ExpertRole>

            {callState === "calling" && <ConnectingBar><span /></ConnectingBar>}

            <Brand>🌿 EXPERT YARD</Brand>
          </ExpertSection>
        )}

        {callState === "ended" && (
          <>
            <StatusText>CALL ENDED</StatusText>
            <EndCallButton onClick={() => navigate(-1)}>
              ✕ <span>Back</span>
            </EndCallButton>
          </>
        )}
      </CallCard>
    </PageWrapper>
  );
}