export const APP_CONFIG = {
  API_BASE_URL: "https://softmaxs.com/api",
  REQUEST_TIMEOUT: 15000
};
