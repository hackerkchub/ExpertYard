import { io } from "socket.io-client";

export const socket = io("https://softmaxs.com", {
  path: "/socket.io",
  transports: ["websocket", "polling"],
  withCredentials: true,
  autoConnect: false,
});

export const updateSocketAuth = () => {
  socket.auth = {
    token: localStorage.getItem("token"),
  };
};