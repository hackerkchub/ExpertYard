import { useEffect, useState, useRef } from "react";
import { useSocket } from "./useSocket";

export function useVoiceCall({ userId, role }) {
  const socket = useSocket(userId);

  const [callState, setCallState] = useState("idle"); 
  // idle | calling | incoming | connected | ended | busy | offline

  const [callId, setCallId] = useState(null);
  const [incoming, setIncoming] = useState(null);

  const remoteAudioRef = useRef(null);

  useEffect(() => {
    if (!socket) return;

    // 🔔 Incoming (expert only)
    socket.on("call:incoming", (data) => {
      if (role === "expert") {
        setIncoming(data);
        setCallState("incoming");
      }
    });

    socket.on("call:connected", ({ callId }) => {
      setCallId(callId);
      setCallState("connected");
    });

    socket.on("call:ended", () => {
      setCallState("ended");
      setIncoming(null);
      setCallId(null);
    });

    socket.on("call:busy", () => setCallState("busy"));
    socket.on("call:offline", () => setCallState("offline"));

    return () => {
      socket.off("call:incoming");
      socket.off("call:connected");
      socket.off("call:ended");
      socket.off("call:busy");
      socket.off("call:offline");
    };
  }, [socket, role]);

  /* ---------- ACTIONS ---------- */

  const startCall = (expertId) => {
    setCallState("calling");
    socket.emit("call:start", { expertId });
  };

  const acceptCall = () => {
    if (!incoming) return;
    socket.emit("call:accept", { callId: incoming.callId });
  };

  const endCall = () => {
    if (!callId) return;
    socket.emit("call:end", { callId });
  };

  return {
    socket,
    callState,
    callId,
    incoming,
    startCall,
    acceptCall,
    endCall,
    remoteAudioRef,
  };
}
