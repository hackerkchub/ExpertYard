export const required = v => !!v;
export const isEmail = v => /\S+@\S+\.\S+/.test(v);
