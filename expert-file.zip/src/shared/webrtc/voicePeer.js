let pc = null;
let localStream = null;

export async function createPeer(socket, callId) {
  pc = new RTCPeerConnection({
    iceServers: [
      { urls: "stun:stun.l.google.com:19302" },
    ],
  });

  // 🎤 Get mic
  localStream = await navigator.mediaDevices.getUserMedia({ audio: true });

  localStream.getTracks().forEach(track => {
    pc.addTrack(track, localStream);
  });

  // 🔊 Play remote audio
 pc.ontrack = (event) => {
  const audio = document.createElement("audio");
  audio.srcObject = event.streams[0];
  audio.autoplay = true;
  audio.muted = false;
  document.body.appendChild(audio);

  audio.play().catch(() => {
    console.log("Autoplay blocked, user interaction needed");
  });
};


  // ❄ ICE
  pc.onicecandidate = (event) => {
    if (event.candidate) {
      socket.emit("webrtc:ice", { callId, candidate: event.candidate });
    }
  };



  return pc;
}

export function getPeer() {
  return pc;
}

export function closePeer() {
  if (pc) pc.close();
  pc = null;

  if (localStream) {
    localStream.getTracks().forEach(t => t.stop());
    localStream = null;
  }
}


export async function setRemote(description) {
  if (!pc) return;
  await pc.setRemoteDescription(description);
}

export async function addIce(candidate) {
  if (!pc || !candidate) return;
  await pc.addIceCandidate(candidate);
}
