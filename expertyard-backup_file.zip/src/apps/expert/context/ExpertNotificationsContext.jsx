import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  useCallback,
} from "react";
import { socket } from "../../../shared/api/socket";

const Ctx = createContext(null);
const STORAGE_KEY = "expert_notifications_v1";

/* ----------------------------------
   Helper: Safe User Name
---------------------------------- */
const getSafeUserName = (user_name, user_id) => {
  if (typeof user_name === "string" && user_name.trim()) {
    return user_name.trim();
  }
  return `User #${user_id}`;
};

export function ExpertNotificationsProvider({ children }) {
  /* ----------------------------------
     INIT STATE (with migration)
  ---------------------------------- */
  const [notifications, setNotifications] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return [];

      const parsed = JSON.parse(saved);

      // 🔄 MIGRATE OLD DATA
      return parsed.map((n) => {
        const safeName = getSafeUserName(
          n?.payload?.user_name,
          n?.payload?.user_id
        );

        return {
          ...n,
          title: `New chat request from ${safeName}`,
          payload: {
            ...n.payload,
            user_name: safeName,
          },
        };
      });
    } catch {
      return [];
    }
  });

  /* ----------------------------------
     Persist to localStorage
  ---------------------------------- */
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications));
    } catch (e) {
      console.warn("Failed to persist notifications", e);
    }
  }, [notifications]);

  /* ----------------------------------
     Unread Count
  ---------------------------------- */
  const unreadCount = useMemo(
    () =>
      notifications.filter(
        (n) => n.unread && n.status !== "cancelled"
      ).length,
    [notifications]
  );

  /* ----------------------------------
     INCOMING CHAT REQUEST
  ---------------------------------- */
  useEffect(() => {
    const onIncoming = ({ request_id, user_id, user_name, expert_id }) => {
      const safeUserName = getSafeUserName(user_name, user_id);

      console.log("🔔 EXPERT GOT REQUEST:", {
        request_id,
        user_id,
        safeUserName,
        expert_id,
      });

      setNotifications((prev) => {
        const existing = prev.find((n) => n.id === request_id);

        // 🔁 UPDATE existing notification (important!)
        if (existing) {
          return prev.map((n) =>
            n.id === request_id
              ? {
                  ...n,
                  title: `New chat request from ${safeUserName}`,
                  payload: {
                    ...n.payload,
                    user_name: safeUserName,
                  },
                }
              : n
          );
        }

        // ➕ ADD new notification
        return [
          {
            id: request_id,
            type: "chat_request",
            status: "pending",
            title: `New chat request from ${safeUserName}`,
            meta: "Tap to accept or decline",
            unread: true,
            payload: {
              request_id,
              user_id,
              user_name: safeUserName,
              expert_id,
            },
            createdAt: Date.now(),
          },
          ...prev,
        ];
      });
    };

    socket.on("incoming_chat_request", onIncoming);
    return () => socket.off("incoming_chat_request", onIncoming);
  }, []);

  /* ----------------------------------
     STATUS UPDATE (accept / reject / cancel)
  ---------------------------------- */
  useEffect(() => {
    const handleRequestStatusUpdate = ({ request_id, status }) => {
      setNotifications((prev) =>
        prev.map((n) =>
          n.id === request_id
            ? {
                ...n,
                status,
                unread: status === "cancelled" ? false : n.unread,
              }
            : n
        )
      );
    };

    socket.on("request_status_update", handleRequestStatusUpdate);
    return () =>
      socket.off("request_status_update", handleRequestStatusUpdate);
  }, []);

  /* ----------------------------------
     ACTIONS
  ---------------------------------- */
  const markAllRead = useCallback(() => {
    setNotifications((prev) =>
      prev.map((n) => ({
        ...n,
        unread: false,
      }))
    );
  }, []);

  const removeById = useCallback((id) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const acceptRequest = useCallback(
    (requestId) => {
      socket.emit("accept_chat", { request_id: requestId });
      removeById(requestId);
    },
    [removeById]
  );

  const declineRequest = useCallback((requestId) => {
    socket.emit("reject_chat", { request_id: requestId });
  }, []);

  /* ----------------------------------
     CONTEXT VALUE
  ---------------------------------- */
  const value = useMemo(
    () => ({
      notifications,
      unreadCount,
      markAllRead,
      acceptRequest,
      declineRequest,
      removeById,
    }),
    [
      notifications,
      unreadCount,
      markAllRead,
      acceptRequest,
      declineRequest,
      removeById,
    ]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

/* ----------------------------------
   Hook
---------------------------------- */
export function useExpertNotifications() {
  const v = useContext(Ctx);
  if (!v) {
    throw new Error(
      "useExpertNotifications must be used inside ExpertNotificationsProvider"
    );
  }
  return v;
}
