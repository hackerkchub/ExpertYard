import React from "react";
import { Outlet } from "react-router-dom";
import Navbar from "../components/Navbar/Navbar";
import Footer from "../components/Footer/Footer";
import UserSocketListener from "../../../shared/socket/UserSocketListener";

export default function MainLayout() {
  return (
    <>
      {/* ✅ GLOBAL USER SOCKET EVENTS */}
      <UserSocketListener />

      <Navbar />
      <Outlet />
      <Footer />
    </>
  );
}
