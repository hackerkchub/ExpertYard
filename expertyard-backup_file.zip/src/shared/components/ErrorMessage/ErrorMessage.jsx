const ErrorMessage = ({ message }) => (
  <p style={{ color: "red" }}>{message}</p>
);

export default ErrorMessage;
