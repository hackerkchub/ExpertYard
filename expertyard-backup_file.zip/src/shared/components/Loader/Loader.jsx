const Loader = () => (
  <div className="loader-overlay">
    Loading...
  </div>
);

export default Loader;
